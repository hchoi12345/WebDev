[My blog](http://sites.bxmc.poly.edu/~hyuntaechoi/WebDev/index.php/blog/)
